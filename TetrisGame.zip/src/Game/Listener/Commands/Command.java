package Game.Listener.Commands;

import Game.TetrisGame;

public interface Command {
    void execute(TetrisGame game);
}
