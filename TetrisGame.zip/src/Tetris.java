import Game.TetrisWindow;

public class Tetris {
    public static void main(String[] args) throws Exception {
        TetrisWindow.getInstance();
    }
}
